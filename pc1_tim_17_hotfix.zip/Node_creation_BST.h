#pragma once
#include "types.h"
#include <iostream>

Node* node_creation(Node* node, int value1);