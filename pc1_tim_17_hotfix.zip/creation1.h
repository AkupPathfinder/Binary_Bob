#pragma once
#include "types.h"
#include <iostream>

void creation1(Node** node, int value1);