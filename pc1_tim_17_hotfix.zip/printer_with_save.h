#pragma once

#include <iostream>
#include "types.h"

void printer_with_save(Node* node, FILE* output);