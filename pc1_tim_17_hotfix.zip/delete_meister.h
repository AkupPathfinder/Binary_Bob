#pragma once
#include "types.h"
#include <iostream>

void delete_meister(Node** node, int value1);